ALTER TABLE `users` ADD `nameColor` varchar(9) NOT NULL DEFAULT '#2F6BFF';--> statement-breakpoint
ALTER TABLE `users` ADD `bio` varchar(180);