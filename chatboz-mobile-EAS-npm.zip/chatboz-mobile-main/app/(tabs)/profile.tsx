import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { useEffect, useState } from "react";
import { ActivityIndicator, Alert, Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { Avatar, buzzColors } from "@/components/buzz-ui";
import { ScreenContainer } from "@/components/screen-container";
import { useLocalAuth } from "@/hooks/use-local-auth";
import { trpc } from "@/lib/trpc";

const NAME_COLORS = ["#2F6BFF", "#7C3AED", "#0F9F79", "#E11D48", "#F97316", "#B45309", "#0891B2", "#DB2777", "#16A34A", "#4F46E5"];

export default function ProfileScreen() {
  const { user: sessionUser, loading, isAuthenticated, logout, updateUser } = useLocalAuth();
  const rooms = trpc.social.rooms.list.useQuery(undefined, { enabled: isAuthenticated });
  const friends = trpc.social.friends.list.useQuery(undefined, { enabled: isAuthenticated });
  const conversations = trpc.social.conversations.list.useQuery(undefined, { enabled: isAuthenticated });
  const profile = trpc.social.profiles.get.useQuery({ userId: sessionUser?.id ?? 0 }, { enabled: isAuthenticated && Boolean(sessionUser?.id) });
  const updateProfile = trpc.social.profiles.update.useMutation();
  const [editOpen, setEditOpen] = useState(false);
  const [name, setName] = useState("");
  const [bio, setBio] = useState("");
  const [nameColor, setNameColor] = useState(NAME_COLORS[0]);

  useEffect(() => {
    if (!profile.data) return;
    setName(profile.data.name);
    setBio(profile.data.bio ?? "");
    setNameColor(profile.data.nameColor || NAME_COLORS[0]);
  }, [profile.data]);

  const saveProfile = async () => {
    try {
      const result = await updateProfile.mutateAsync({ name, bio: bio || undefined, nameColor });
      await updateUser({ name: result.name, nameColor: result.nameColor });
      setEditOpen(false);
      await profile.refetch();
      Alert.alert("تم الحفظ", "تم تحديث اسم الحساب ولونه والنبذة مجانًا.");
    } catch (error) { Alert.alert("تعذر الحفظ", error instanceof Error ? error.message : "حاول مرة أخرى."); }
  };

  if (loading || profile.isLoading) return <ScreenContainer className="items-center justify-center"><ActivityIndicator color={buzzColors.indigo} /></ScreenContainer>;
  if (!isAuthenticated || !sessionUser) return <ScreenContainer className="items-center justify-center px-6"><Text style={styles.emptyTitle}>حسابك مطلوب</Text><Text style={styles.emptyCopy}>سجّل الدخول لاستخدام ملفك الشخصي.</Text><Pressable onPress={() => router.push("/login")} style={styles.primary}><Text style={styles.primaryText}>تسجيل الدخول</Text></Pressable></ScreenContainer>;
  const user = profile.data;
  if (!user) return null;
  const nameColorValue = user.nameColor || buzzColors.indigo;
  return <ScreenContainer edges={["top", "left", "right"]}><ScrollView contentContainerStyle={styles.scroll}>
    <View style={styles.header}><Pressable onPress={() => setEditOpen(true)} style={styles.iconButton}><MaterialIcons name="edit" color={buzzColors.indigo} size={21} /></Pressable><Text style={styles.heading}>ملفي</Text><Pressable onPress={() => router.push(user.role === "admin" ? "/admin" : user.role === "agent" ? "/staff" : "/settings")} style={styles.iconButton}><MaterialIcons name={user.role === "admin" ? "admin-panel-settings" : user.role === "agent" ? "manage-accounts" : "settings"} color={buzzColors.indigo} size={22} /></Pressable></View>
    <Pressable onPress={() => setEditOpen(true)} style={styles.card}><Avatar initials={user.name.slice(0, 1) || "؟"} tint={nameColorValue} size={82} /><Text style={[styles.name, { color: nameColorValue }]}>{user.name}</Text><Text style={styles.caption}>@{user.username || "—"} · {user.role === "admin" ? "مدير" : user.role === "agent" ? "وكيل" : "عضو"}</Text>{user.points !== null ? <View style={styles.points}><MaterialIcons name="diamond" color="#C58A13" size={19} /><Text style={styles.pointsText}>{user.points} نقطة</Text></View> : <View style={styles.adminHidden}><MaterialIcons name="verified-user" color={buzzColors.indigo} size={18} /><Text style={styles.adminHiddenText}>حساب إداري — الرصيد غير ظاهر</Text></View>}<Text style={styles.bio}>{user.bio || "أضف نبذة قصيرة عنك من زر التعديل."}</Text><View style={styles.stats}><Stat value={user.stats.rooms} label="غرف" /><View style={styles.divider} /><Stat value={user.stats.friends} label="أصدقاء" /><View style={styles.divider} /><Stat value={user.stats.messages} label="رسائل" /></View></Pressable>
    {user.role !== "user" ? <Pressable onPress={() => router.push(user.role === "admin" ? "/admin" : "/staff")} style={styles.adminAction}><MaterialIcons name={user.role === "admin" ? "admin-panel-settings" : "manage-accounts"} color="#FFFFFF" size={21} /><Text style={styles.adminActionText}>{user.role === "admin" ? "لوحة المدير وتحويل النقاط" : "لوحة الوكيل"}</Text></Pressable> : null}
    <Pressable onPress={() => router.push("/ludo")} style={styles.gameAction}><MaterialIcons name="casino" color="#FFFFFF" size={22} /><View style={{ flex: 1, alignItems: "flex-end" }}><Text style={styles.gameTitle}>لعبة لودو</Text><Text style={styles.gameSub}>ابدأ مباراة سريعة</Text></View><MaterialIcons name="chevron-left" color="#FFFFFF" size={24} /></Pressable>
    <Pressable onPress={() => void logout()} style={styles.logout}><MaterialIcons name="logout" color="#C94458" size={21} /><Text style={styles.logoutText}>تسجيل الخروج</Text></Pressable>
  </ScrollView>
  <Modal visible={editOpen} transparent animationType="slide" onRequestClose={() => setEditOpen(false)}>
    <View style={styles.shade}><View style={styles.sheet}><Text style={styles.sheetTitle}>تعديل الملف</Text><TextInput value={name} onChangeText={setName} placeholder="اسم الحساب" placeholderTextColor="#A5A5B5" style={styles.input} textAlign="right" maxLength={50} /><TextInput value={bio} onChangeText={setBio} placeholder="نبذة قصيرة" placeholderTextColor="#A5A5B5" style={[styles.input, styles.bioInput]} textAlign="right" multiline maxLength={180} /><Text style={styles.colorTitle}>لون اسم الحساب — مجاني</Text><View style={styles.colors}>{NAME_COLORS.map((color) => <Pressable key={color} onPress={() => setNameColor(color)} style={[styles.swatch, { backgroundColor: color }, nameColor === color && styles.swatchSelected]} />)}</View><Pressable disabled={updateProfile.isPending} onPress={() => void saveProfile()} style={[styles.save, updateProfile.isPending && { opacity: 0.5 }]}><Text style={styles.saveText}>{updateProfile.isPending ? "جارٍ الحفظ..." : "حفظ التعديلات"}</Text></Pressable><Pressable onPress={() => setEditOpen(false)} style={styles.cancel}><Text style={styles.cancelText}>إلغاء</Text></Pressable></View></View>
  </Modal>
  </ScreenContainer>;
}
function Stat({ value, label }: { value: number; label: string }) { return <View style={styles.stat}><Text style={styles.statValue}>{value}</Text><Text style={styles.statLabel}>{label}</Text></View>; }
const styles = StyleSheet.create({ scroll: { padding: 17, paddingBottom: 35 }, header: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }, heading: { color: buzzColors.ink, fontSize: 28, fontWeight: "900", writingDirection: "rtl" }, iconButton: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#ECECF3", alignItems: "center", justifyContent: "center" }, card: { alignItems: "center", backgroundColor: "#FFFFFF", borderRadius: 25, padding: 23, borderWidth: 1, borderColor: "#ECECF3" }, name: { fontSize: 23, fontWeight: "900", marginTop: 12, writingDirection: "rtl" }, caption: { color: buzzColors.muted, fontSize: 12, marginTop: 4, writingDirection: "rtl" }, points: { marginTop: 11, flexDirection: "row-reverse", alignItems: "center", gap: 5, paddingHorizontal: 11, paddingVertical: 7, borderRadius: 13, backgroundColor: "#FFF8E8" }, pointsText: { color: "#986A10", fontSize: 12, fontWeight: "900", writingDirection: "rtl" }, adminHidden: { marginTop: 11, flexDirection: "row-reverse", alignItems: "center", gap: 5, paddingHorizontal: 11, paddingVertical: 7, borderRadius: 13, backgroundColor: "#EFEEFF" }, adminHiddenText: { color: buzzColors.indigo, fontSize: 11, fontWeight: "900", writingDirection: "rtl" }, bio: { color: buzzColors.muted, fontSize: 12, lineHeight: 19, textAlign: "center", marginTop: 12, writingDirection: "rtl" }, stats: { alignSelf: "stretch", flexDirection: "row-reverse", alignItems: "center", marginTop: 20, paddingTop: 17, borderTopWidth: 1, borderTopColor: "#F0F0F5" }, stat: { flex: 1, alignItems: "center" }, statValue: { color: buzzColors.ink, fontSize: 19, fontWeight: "900" }, statLabel: { color: buzzColors.muted, fontSize: 10, marginTop: 4, writingDirection: "rtl", textAlign: "center" }, divider: { height: 29, width: 1, backgroundColor: "#E9E9F0" }, adminAction: { height: 51, borderRadius: 16, backgroundColor: buzzColors.indigo, marginTop: 12, flexDirection: "row-reverse", gap: 8, alignItems: "center", justifyContent: "center" }, adminActionText: { color: "#FFFFFF", fontSize: 14, fontWeight: "900", writingDirection: "rtl" }, gameAction: { marginTop: 12, height: 62, borderRadius: 19, backgroundColor: "#5B4FD7", paddingHorizontal: 15, flexDirection: "row-reverse", alignItems: "center", gap: 11 }, gameTitle: { color: "#FFFFFF", fontSize: 15, fontWeight: "900", writingDirection: "rtl" }, gameSub: { color: "#DCD9FF", fontSize: 10, marginTop: 2, writingDirection: "rtl" }, logout: { marginTop: 12, height: 51, backgroundColor: "#FFF0F2", borderRadius: 16, flexDirection: "row-reverse", gap: 8, alignItems: "center", justifyContent: "center" }, logoutText: { color: "#C94458", fontSize: 14, fontWeight: "900", writingDirection: "rtl" }, emptyTitle: { color: buzzColors.ink, fontSize: 21, fontWeight: "900", writingDirection: "rtl" }, emptyCopy: { color: buzzColors.muted, fontSize: 13, textAlign: "center", marginTop: 7, writingDirection: "rtl" }, primary: { marginTop: 18, height: 49, paddingHorizontal: 20, borderRadius: 16, backgroundColor: buzzColors.indigo, alignItems: "center", justifyContent: "center" }, primaryText: { color: "#FFFFFF", fontSize: 14, fontWeight: "900", writingDirection: "rtl" }, shade: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(20,20,35,0.45)" }, sheet: { backgroundColor: "#FFFFFF", borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 20, paddingBottom: 30 }, sheetTitle: { color: buzzColors.ink, fontSize: 21, fontWeight: "900", textAlign: "right", writingDirection: "rtl" }, input: { height: 51, marginTop: 12, borderRadius: 15, backgroundColor: "#F6F6FA", paddingHorizontal: 13, color: buzzColors.ink, fontSize: 14, writingDirection: "rtl" }, bioInput: { height: 80, paddingTop: 13, textAlignVertical: "top" }, colorTitle: { color: buzzColors.ink, fontSize: 13, fontWeight: "900", textAlign: "right", writingDirection: "rtl", marginTop: 18 }, colors: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 11, marginTop: 11 }, swatch: { width: 32, height: 32, borderRadius: 16, borderWidth: 2, borderColor: "#FFFFFF" }, swatchSelected: { borderColor: "#111827", transform: [{ scale: 1.14 }] }, save: { height: 51, borderRadius: 16, backgroundColor: buzzColors.indigo, alignItems: "center", justifyContent: "center", marginTop: 18 }, saveText: { color: "#FFFFFF", fontSize: 14, fontWeight: "900", writingDirection: "rtl" }, cancel: { height: 44, alignItems: "center", justifyContent: "center" }, cancelText: { color: buzzColors.indigo, fontSize: 13, fontWeight: "900", writingDirection: "rtl" } });
