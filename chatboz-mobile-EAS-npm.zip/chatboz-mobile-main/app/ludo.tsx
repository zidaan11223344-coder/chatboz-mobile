import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router } from "expo-router";
import { useMemo, useState } from "react";
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { buzzColors } from "@/components/buzz-ui";

type Player = { name: string; color: string; pieces: number[] };
const COLORS = ["#E53935", "#43A047", "#1E88E5", "#FB8C00"];
const NAMES = ["الأحمر", "الأخضر", "الأزرق", "البرتقالي"];
const STARTS = [0, 13, 26, 39];

function pathCells() {
  const cells: { r: number; c: number }[] = [];
  for (let c = 0; c < 14; c++) cells.push({ r: 0, c });
  for (let r = 1; r < 14; r++) cells.push({ r, c: 13 });
  for (let c = 12; c >= 0; c--) cells.push({ r: 13, c });
  for (let r = 12; r >= 1; r--) cells.push({ r, c: 0 });
  return cells;
}
const PATH = pathCells();

export default function LudoScreen() {
  const [playersCount, setPlayersCount] = useState(2);
  const [players, setPlayers] = useState<Player[]>(() => NAMES.slice(0, 2).map((name, i) => ({ name, color: COLORS[i], pieces: [-1, -1, -1, -1] })));
  const [turn, setTurn] = useState(0);
  const [dice, setDice] = useState<number | null>(null);
  const [rolling, setRolling] = useState(false);
  const [winner, setWinner] = useState<string | null>(null);

  const reset = (count = playersCount) => {
    setPlayers(NAMES.slice(0, count).map((name, i) => ({ name, color: COLORS[i], pieces: [-1, -1, -1, -1] })));
    setTurn(0); setDice(null); setWinner(null); setRolling(false);
  };

  const current = players[turn];
  const legalPieces = useMemo(() => {
    if (!current || dice === null) return [];
    return current.pieces.map((p, i) => (p === -1 ? (dice === 6 ? i : -1) : (p + dice <= 52 ? i : -1))).filter((i) => i >= 0);
  }, [current, dice]);

  const roll = () => {
    if (rolling || winner) return;
    setRolling(true);
    setTimeout(() => {
      const value = Math.floor(Math.random() * 6) + 1;
      setDice(value);
      setRolling(false);
      if (current && !current.pieces.some((p) => p === -1 ? value === 6 : p + value <= 52)) {
        setTimeout(() => setTurn((turn + 1) % players.length), 450);
      }
    }, 350);
  };

  const move = (pieceIndex: number) => {
    if (dice === null || !legalPieces.includes(pieceIndex) || winner) return;
    const rollValue = dice;
    const next = players.map((player, pi) => ({ ...player, pieces: [...player.pieces] }));
    const oldProgress = next[turn].pieces[pieceIndex];
    const newProgress = oldProgress === -1 ? 0 : oldProgress + rollValue;
    next[turn].pieces[pieceIndex] = newProgress;

    if (newProgress < 52) {
      const landed = (STARTS[turn] + newProgress) % 52;
      const safe = STARTS.some((s) => s === landed);
      if (!safe) {
        next.forEach((player, pi) => {
          if (pi === turn) return;
          player.pieces = player.pieces.map((progress) => {
            if (progress < 0 || progress >= 52) return progress;
            return (STARTS[pi] + progress) % 52 === landed ? -1 : progress;
          });
        });
      }
    }
    const didWin = next[turn].pieces.every((p) => p === 52);
    setPlayers(next);
    setDice(null);
    if (didWin) { setWinner(next[turn].name); return; }
    if (rollValue !== 6) setTurn((turn + 1) % next.length);
  };

  const tokenAt = (cellIndex: number) => players.flatMap((player, pi) => player.pieces.map((progress, piece) => ({ pi, piece, progress }))).filter(({ pi, progress }) => progress >= 0 && progress < 52 && (STARTS[pi] + progress) % 52 === cellIndex);

  return <ScreenContainer edges={["top", "left", "right", "bottom"]}><ScrollView contentContainerStyle={styles.scroll}>
    <View style={styles.header}><Pressable onPress={() => router.back()} style={styles.back}><MaterialIcons name="arrow-forward" size={23} color={buzzColors.ink} /></Pressable><View style={styles.headCopy}><Text style={styles.title}>لودو</Text><Text style={styles.subtitle}>لعبة محلية سريعة</Text></View><Pressable onPress={() => reset()} style={styles.reset}><MaterialIcons name="refresh" size={20} color={buzzColors.indigo} /></Pressable></View>
    <View style={styles.playersRow}>{NAMES.map((name, i) => <Pressable key={name} disabled={i >= 4} onPress={() => { if (i < 4) { setPlayersCount(i + 1); reset(i + 1); } }} style={[styles.playerChoice, i < playersCount && { borderColor: COLORS[i], backgroundColor: "#FFFFFF" }]}><View style={[styles.dot, { backgroundColor: COLORS[i] }]} /><Text style={styles.playerChoiceText}>{name}</Text></Pressable>)}</View>
    <View style={styles.turnCard}><View style={[styles.turnDot, { backgroundColor: current?.color || COLORS[0] }]} /><View style={{ flex: 1, alignItems: "flex-end" }}><Text style={styles.turnLabel}>دور اللاعب</Text><Text style={[styles.turnName, { color: current?.color || COLORS[0] }]}>{winner ? `الفائز: ${winner}` : current?.name}</Text></View><View style={styles.dice}><Text style={styles.diceText}>{dice ?? "—"}</Text></View></View>
    <View style={styles.board}>{PATH.map((cell, index) => { const tokens = tokenAt(index); return <View key={`${cell.r}-${cell.c}`} style={[styles.cell, { left: cell.c * 100 / 14 + "%", top: cell.r * 100 / 14 + "%" }, STARTS.includes(index) && { borderColor: COLORS[STARTS.indexOf(index)], borderWidth: 2 }]}>{tokens.map((t) => <Pressable key={`${t.pi}-${t.piece}`} disabled={!legalPieces.includes(t.piece) || t.pi !== turn} onPress={() => move(t.piece)} style={[styles.token, { backgroundColor: COLORS[t.pi] }]}><Text style={styles.tokenText}>{t.piece + 1}</Text></Pressable>)}</View>; })}<View style={styles.center}><MaterialIcons name="casino" size={38} color="#FFFFFF" /><Text style={styles.centerText}>لودو</Text></View>{[0,1,2,3].map((i) => <View key={i} style={[styles.home, homePosition(i)]}><View style={[styles.homeInner, { borderColor: COLORS[i] }]}>{[0,1,2,3].map((p) => <Pressable key={p} disabled={turn !== i || !legalPieces.includes(p)} onPress={() => move(p)} style={[styles.baseToken, { backgroundColor: COLORS[i] }, players[i]?.pieces[p] === -1 && styles.baseTokenReady]}><Text style={styles.tokenText}>{p + 1}</Text></Pressable>)}</View></View>)}</View>
    <View style={styles.controls}><Pressable disabled={rolling || Boolean(winner)} onPress={roll} style={[styles.rollButton, (rolling || winner) && styles.disabled]}><MaterialIcons name="casino" size={22} color="#FFFFFF" /><Text style={styles.rollText}>{rolling ? "جارٍ الرمي..." : dice === null ? "ارمِ النرد" : legalPieces.length ? "اختر قطعة" : "لا حركة"}</Text></Pressable><Pressable onPress={() => reset()} style={styles.newButton}><Text style={styles.newText}>لعبة جديدة</Text></Pressable></View>
    <Text style={styles.help}>القطعة تدخل من القاعدة عند ظهور 6. الحصول على 6 يعطيك دورًا إضافيًا، والهبوط على قطعة خصم يعيدها إلى القاعدة.</Text>
  </ScrollView></ScreenContainer>;
}
function homePosition(i: number) { return [{ left: "4%", top: "4%" }, { right: "4%", top: "4%" }, { right: "4%", bottom: "4%" }, { left: "4%", bottom: "4%" }][i]; }
const styles = StyleSheet.create({ scroll: { padding: 16, paddingBottom: 30 }, header: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }, headCopy: { flex: 1, alignItems: "flex-end", marginRight: 11 }, title: { color: buzzColors.ink, fontSize: 27, fontWeight: "900", writingDirection: "rtl" }, subtitle: { color: buzzColors.muted, fontSize: 10, marginTop: 2, writingDirection: "rtl" }, back: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#ECECF3", alignItems: "center", justifyContent: "center" }, reset: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#EFEEFF", alignItems: "center", justifyContent: "center" }, playersRow: { flexDirection: "row-reverse", gap: 6, marginBottom: 10 }, playerChoice: { flex: 1, height: 40, borderRadius: 13, borderWidth: 1, borderColor: "#E5E5EE", backgroundColor: "#F7F7FA", flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 4 }, playerChoiceText: { color: buzzColors.ink, fontSize: 9, fontWeight: "900", writingDirection: "rtl" }, dot: { width: 8, height: 8, borderRadius: 4 }, turnCard: { backgroundColor: "#FFFFFF", borderRadius: 19, padding: 11, flexDirection: "row-reverse", alignItems: "center", borderWidth: 1, borderColor: "#ECECF3", marginBottom: 12 }, turnDot: { width: 42, height: 42, borderRadius: 15 }, turnLabel: { color: buzzColors.muted, fontSize: 10, writingDirection: "rtl" }, turnName: { fontSize: 15, fontWeight: "900", marginTop: 2, writingDirection: "rtl" }, dice: { width: 50, height: 50, borderRadius: 15, backgroundColor: "#171725", alignItems: "center", justifyContent: "center", marginLeft: 8 }, diceText: { color: "#FFFFFF", fontSize: 22, fontWeight: "900" }, board: { width: "100%", aspectRatio: 1, backgroundColor: "#F0F0F7", borderRadius: 22, borderWidth: 2, borderColor: "#DCDCE8", position: "relative", overflow: "hidden" }, cell: { position: "absolute", width: `${100/14}%`, height: `${100/14}%`, borderWidth: 1, borderColor: "#DCDCE8", backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center" }, token: { width: 22, height: 22, borderRadius: 11, alignItems: "center", justifyContent: "center", borderWidth: 2, borderColor: "#FFFFFF", margin: -1 }, tokenText: { color: "#FFFFFF", fontSize: 8, fontWeight: "900" }, center: { position: "absolute", left: "35%", top: "35%", width: "30%", height: "30%", borderRadius: 25, backgroundColor: "#5B4FD7", alignItems: "center", justifyContent: "center" }, centerText: { color: "#FFFFFF", fontSize: 10, fontWeight: "900", marginTop: 2 }, home: { position: "absolute", width: "27%", height: "27%", backgroundColor: "rgba(255,255,255,0.92)", borderRadius: 18, padding: 5 }, homeInner: { flex: 1, borderWidth: 3, borderRadius: 14, borderStyle: "dashed", alignItems: "center", justifyContent: "center", flexDirection: "row", flexWrap: "wrap", gap: 4 }, baseToken: { width: 24, height: 24, borderRadius: 12, alignItems: "center", justifyContent: "center", opacity: 0.72 }, baseTokenReady: { opacity: 1, transform: [{ scale: 1.08 }] }, controls: { flexDirection: "row-reverse", gap: 8, marginTop: 12 }, rollButton: { flex: 1, height: 53, borderRadius: 17, backgroundColor: buzzColors.indigo, alignItems: "center", justifyContent: "center", flexDirection: "row-reverse", gap: 8 }, rollText: { color: "#FFFFFF", fontSize: 14, fontWeight: "900", writingDirection: "rtl" }, newButton: { height: 53, paddingHorizontal: 17, borderRadius: 17, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#DCDCEC", alignItems: "center", justifyContent: "center" }, newText: { color: buzzColors.indigo, fontSize: 12, fontWeight: "900", writingDirection: "rtl" }, disabled: { opacity: 0.5 }, help: { color: buzzColors.muted, fontSize: 11, lineHeight: 18, textAlign: "center", writingDirection: "rtl", marginTop: 13 } });
