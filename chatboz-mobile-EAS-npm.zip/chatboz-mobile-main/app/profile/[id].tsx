import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { router, useLocalSearchParams } from "expo-router";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { Avatar, buzzColors } from "@/components/buzz-ui";
import { ScreenContainer } from "@/components/screen-container";
import { useLocalAuth } from "@/hooks/use-local-auth";
import { trpc } from "@/lib/trpc";

export default function UserProfileScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { isAuthenticated } = useLocalAuth();
  const profile = trpc.social.profiles.get.useQuery({ userId: Number(id) }, { enabled: isAuthenticated && Number.isFinite(Number(id)) });
  if (profile.isLoading) return <ScreenContainer className="items-center justify-center"><ActivityIndicator color={buzzColors.indigo} /></ScreenContainer>;
  if (!profile.data) return <ScreenContainer className="items-center justify-center px-6"><Text style={styles.empty}>تعذر العثور على الحساب.</Text></ScreenContainer>;
  const user = profile.data;
  return <ScreenContainer edges={["top", "left", "right", "bottom"]}><ScrollView contentContainerStyle={styles.scroll}>
    <View style={styles.header}><Pressable onPress={() => router.back()} style={styles.iconButton}><MaterialIcons name="arrow-forward" size={23} color={buzzColors.ink} /></Pressable><Text style={styles.heading}>الملف الشخصي</Text><View style={styles.blank} /></View>
    <View style={styles.hero}>
      <View style={styles.avatarWrap}><Avatar initials={user.name.slice(0, 1) || "؟"} tint={user.nameColor || buzzColors.indigo} size={88} /></View>
      <Text style={[styles.name, { color: user.nameColor || buzzColors.indigo }]}>{user.name}</Text>
      <Text style={styles.username}>@{user.username || "مستخدم"}</Text>
      <View style={styles.rolePill}><MaterialIcons name={user.role === "admin" ? "verified" : user.role === "agent" ? "support-agent" : "person"} size={16} color={user.role === "admin" ? "#B27A00" : buzzColors.indigo} /><Text style={styles.roleText}>{user.role === "admin" ? "مدير" : user.role === "agent" ? "وكيل" : "عضو"}</Text></View>
      {user.bio ? <Text style={styles.bio}>{user.bio}</Text> : <Text style={styles.bioMuted}>لا توجد نبذة شخصية.</Text>}
      {user.points !== null ? <View style={styles.points}><MaterialIcons name="diamond" color="#986A10" size={18} /><Text style={styles.pointsText}>{user.points} نقطة</Text></View> : null}
    </View>
    <View style={styles.stats}><Stat icon="hub" value={user.stats.rooms} label="غرف" /><Stat icon="group" value={user.stats.friends} label="أصدقاء" /><Stat icon="chat" value={user.stats.messages} label="رسائل" /></View>
    <Text style={styles.memberSince}>عضو منذ {new Date(user.createdAt).toLocaleDateString("ar-YE")}</Text>
  </ScrollView></ScreenContainer>;
}
function Stat({ icon, value, label }: { icon: keyof typeof MaterialIcons.glyphMap; value: number; label: string }) { return <View style={styles.stat}><MaterialIcons name={icon} size={21} color={buzzColors.indigo} /><Text style={styles.statValue}>{value}</Text><Text style={styles.statLabel}>{label}</Text></View>; }
const styles = StyleSheet.create({ scroll: { padding: 17, paddingBottom: 35 }, header: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }, heading: { color: buzzColors.ink, fontSize: 27, fontWeight: "900", writingDirection: "rtl" }, iconButton: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#ECECF3", alignItems: "center", justifyContent: "center" }, blank: { width: 42 }, hero: { backgroundColor: "#FFFFFF", borderRadius: 27, borderWidth: 1, borderColor: "#ECECF3", alignItems: "center", padding: 24 }, avatarWrap: { padding: 5, borderRadius: 50, backgroundColor: "#F4F4FA" }, name: { fontSize: 24, fontWeight: "900", marginTop: 13, writingDirection: "rtl" }, username: { color: buzzColors.muted, fontSize: 12, marginTop: 4 }, rolePill: { flexDirection: "row-reverse", alignItems: "center", gap: 5, backgroundColor: "#F1F0FF", borderRadius: 14, paddingHorizontal: 10, paddingVertical: 6, marginTop: 10 }, roleText: { color: buzzColors.indigo, fontSize: 11, fontWeight: "900", writingDirection: "rtl" }, bio: { color: buzzColors.ink, fontSize: 13, lineHeight: 21, textAlign: "center", writingDirection: "rtl", marginTop: 13 }, bioMuted: { color: "#A5A5B5", fontSize: 12, marginTop: 13, writingDirection: "rtl" }, points: { flexDirection: "row-reverse", alignItems: "center", gap: 5, backgroundColor: "#FFF8E8", borderRadius: 14, paddingHorizontal: 12, paddingVertical: 7, marginTop: 12 }, pointsText: { color: "#986A10", fontSize: 12, fontWeight: "900" }, stats: { flexDirection: "row-reverse", gap: 9, marginTop: 12 }, stat: { flex: 1, backgroundColor: "#FFFFFF", borderRadius: 18, borderWidth: 1, borderColor: "#ECECF3", alignItems: "center", paddingVertical: 15 }, statValue: { color: buzzColors.ink, fontSize: 19, fontWeight: "900", marginTop: 6 }, statLabel: { color: buzzColors.muted, fontSize: 10, marginTop: 2, writingDirection: "rtl" }, memberSince: { color: buzzColors.muted, fontSize: 11, textAlign: "center", marginTop: 15, writingDirection: "rtl" }, empty: { color: buzzColors.ink, fontSize: 18, fontWeight: "900", writingDirection: "rtl" } });
